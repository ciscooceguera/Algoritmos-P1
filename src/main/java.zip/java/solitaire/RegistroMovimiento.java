package solitaire;

public class RegistroMovimiento {

    enum Tipo {
        DRAW,
        RELOAD,
        WASTE_TO_TABLEAU,
        WASTE_TO_FOUNDATION,
        TABLEAU_TO_FOUNDATION,
        TABLEAU_TO_TABLEAU}

        final Tipo tipo;

    }

}
